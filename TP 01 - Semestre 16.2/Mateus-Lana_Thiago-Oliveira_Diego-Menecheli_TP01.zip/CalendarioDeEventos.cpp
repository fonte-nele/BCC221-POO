#include "CalendarioDeEventos.h"

void CalendarioDeEventos::visualizarCalendario()
{
    cout<<"\nExibe a lista de eventos marcados"<<endl;
}

void CalendarioDeEventos::sugerirEvento()
{
    evento.criarEvento();
}