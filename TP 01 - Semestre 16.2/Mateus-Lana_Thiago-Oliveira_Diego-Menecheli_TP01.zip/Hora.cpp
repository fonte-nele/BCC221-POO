#include "Hora.h"

int Hora::getHora() 
{ 
	return hora;
}
void Hora::setHora(int h) 
{ 
	hora = h;
}
int Hora::getMinuto() 
{
	return minuto;
}
void Hora::setMinuto(int m)
{ 
	minuto = m; 
}