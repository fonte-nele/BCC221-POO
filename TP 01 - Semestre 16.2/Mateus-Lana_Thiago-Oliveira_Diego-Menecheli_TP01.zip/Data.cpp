#include "Data.h"

int Data::getDia()
{
	return dia;
}

void Data::setDia(int d) 
{ 
	dia = d; 
}

int Data::getMes() 
{ 
	return mes; 
}

void Data::setMes(int m) 
{ 
	mes = m; 
}

int Data::getAno() 
{ 
	return ano; 
}

void Data::setAno(int a) 
{ 
	ano = a; 
}