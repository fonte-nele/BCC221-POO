#include "Cadastro.h"
#include "Perfil.h"

void Cadastro::efetuarCadastro(Menu* menu)
{
    perfil.criarPerfil();
}
