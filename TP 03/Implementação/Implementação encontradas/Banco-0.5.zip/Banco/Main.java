
public class Main
{
   public static void main(String[] args)
   {
      
      GerenciaBancos gerente = new GerenciaBancos();
      gerente.setVisible(true);
   }

}
